<div class="thethefly-submit-buttons">
  <input name="submit[]" class="button-primary" value="Save" type="submit" />
  <input name="submit[save_and_exit]" class="button-secondary" value="Save &amp; Exit" type="submit" />
  <input name="submit[save_and_add_new_slide]" class="button-secondary" value="Save &amp; Add New Slide" type="submit" />
  <input name="reset" class="button-secondary" value="Reset To Defaults" type="submit" />
</div>
