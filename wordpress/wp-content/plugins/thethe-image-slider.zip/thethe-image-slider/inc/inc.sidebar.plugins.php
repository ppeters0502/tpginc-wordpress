<?php /** @version $Id: inc.sidebar.plugins.php 943 2011-08-17 14:00:17Z lexx-ua $ */
echo implode('', file ('http://thethefly.com/thethe.sidebar.plugins.php'));
?>