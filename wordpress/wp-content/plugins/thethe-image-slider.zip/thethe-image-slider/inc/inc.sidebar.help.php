<?php /** @version $Id: inc.sidebar.help.php 1002 2011-09-02 10:20:46Z lexx-ua $ */ ?>
<div class="help-res postbox">
  <div class="handlediv" title="<?php _e( 'Click to toggle' ); ?>"><br />
  </div>
  <h3 class="hndle"> <span>Help by TheThe Fly</span> </h3>
  <div class="inside">
    <ul class="cols-2">
      <li><a href="http://thethefly.com/documents/" target="_blank" >Documentations</a></li>
      <li><a href='http://thethefly.com/support/forum/' target="_blank" >Support Forum</a></li>
    </ul>
  </div>
</div>